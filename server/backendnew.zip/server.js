const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());

// ✅ CORS fix for Twitch Extension
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST']
}));

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
}).then(() => console.log('MongoDB Connected'))
.catch(err => console.error(err));

// Routes
app.use('/v1/interact', require('./routes/interact'));
app.use('/v1/leaderboard', require('./routes/leaderboard'));

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
